import UIKit
class ViewController: UIViewController {

    @IBOutlet weak var animalsView: UIView!
    @IBOutlet weak var animals: UIImageView!
    @IBOutlet weak var happyBar: DisplayView!
    @IBOutlet weak var foodBar: DisplayView!
    @IBOutlet weak var happyText: UILabel!
    @IBOutlet weak var foodText: UILabel!
    @IBOutlet weak var Happy: UILabel!
    @IBOutlet weak var Yummy: UILabel!
    @IBOutlet weak var Hungry: UILabel!
    
    var flag = 0
    var dog:Pet=Pet(color: UIColor(red:205/255.0,green:92/255.0,blue:92/255.0,alpha:1.0))
    var cat:Pet=Pet(color: UIColor(red:135/255.0,green:206/255.0,blue:250/255.0,alpha:1.0))
    var bird:Pet=Pet(color: UIColor(red:255/255.0,green:215/255.0,blue:0/255.0,alpha:1.0))
    var bunny:Pet=Pet(color: UIColor(red:152/255.0,green:251/255.0,blue:152/255.0,alpha:1.0))
    var fish:Pet=Pet(color: UIColor(red:255/255.0,green:182/255.0,blue:193/255.0,alpha:1.0))

    override func viewDidLoad() {
        super.viewDidLoad()
        animalsView.backgroundColor = dog.color
        happyBar.color = UIColor(red:205/255.0,green:92/255.0,blue:92/255.0,alpha:1.0)
        foodBar.color = UIColor(red:205/255.0,green:92/255.0,blue:92/255.0,alpha:1.0)
        Happy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
        Yummy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
        Hungry.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func choosePet(pet:Pet){
        Happy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
        Yummy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
        Hungry.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
        animalsView.backgroundColor = pet.color
        happyBar.color = pet.color
        foodBar.color = pet.color
        happyText.text = String(pet.happy)
        foodText.text = String(pet.f)
        foodBar.animateValue(to:CGFloat(Double(pet.food)/10.0))
        happyBar.animateValue(to:CGFloat(Double(pet.happy)/10.0))
    }
    
    
    @IBAction func choosedog(_ sender: Any) {
        flag = 0
        animals.image = UIImage(named:"dog@2x.png")
        choosePet(pet: dog)
    }
    
    @IBAction func choosecat(_ sender: Any) {
        flag = 1
        animals.image = UIImage(named:"cat@2x.png")
        choosePet(pet: cat)
    }
    
    @IBAction func choosebird(_ sender: Any) {
        flag = 2
        animals.image = UIImage(named:"bird@2x.png")
        choosePet(pet: bird)
    }
    
    @IBAction func choosebunny(_ sender: Any) {
        flag = 3
        animals.image = UIImage(named:"bunny@2x.png")
        choosePet(pet: bunny)
    }
    
    @IBAction func choosefish(_ sender: Any) {
        flag = 4
        animals.image = UIImage(named:"fish@2x.png")
        choosePet(pet: fish)
    }
    
    @IBAction func feed(_ sender: Any) {
        Happy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
        Yummy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:1.0)
        Hungry.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
        if flag==0 {
            dog.f = dog.f+1
            if dog.food<10 {
                dog.food = dog.food+1
            }
            foodBar.animateValue(to: CGFloat(Double(dog.food)/10.0))
            foodText.text = String(dog.f)
        }
        
        else if flag==1 {
            cat.f = cat.f+1
            if cat.food<10 {
                cat.food = cat.food+1
            }
            foodBar.animateValue(to:CGFloat(Double(cat.food)/10.0))
            foodText.text = String(cat.f)
        }
            
        else if flag==2 {
            bird.f = bird.f+1
            if bird.food<10 {
                bird.food = bird.food+1
            }
            foodBar.animateValue(to:CGFloat(Double(bird.food)/10.0))
            foodText.text = String(bird.f)
        }
            
        else if flag==3 {
            bunny.f = bunny.f+1
            if bunny.food<10 {
                bunny.food = bunny.food+1
            }
            foodBar.animateValue(to:CGFloat(Double(bunny.food)/10.0))
            foodText.text = String(bunny.f)
        }
        
        else if flag==4 {
            fish.food = fish.food+1
            if fish.food<10 {
                fish.f = fish.f+1
            }
            foodBar.animateValue(to:CGFloat(Double(fish.food)/10.0))
            foodText.text = String(fish.f)
        }
    }
    
    @IBAction func play(_ sender: Any) {
        if flag==0 {
            if dog.food>0 {
                Happy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:1.0)
                Yummy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Hungry.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                dog.food=dog.food-1
                dog.happy=dog.happy+1
                foodBar.animateValue(to:CGFloat(Double(dog.food)/10.0))
                foodText.text = String(dog.f)
                happyBar.animateValue(to:CGFloat(Double(dog.happy)/10.0))
                happyText.text = String(dog.happy)
            }
            else{
                Happy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Yummy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Hungry.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:1.0)
            }
        }
        else if flag==1 {
            if cat.food>0 {
                Happy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:1.0)
                Yummy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Hungry.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                cat.food=cat.food-1
                cat.happy=cat.happy+1
                foodBar.animateValue(to:CGFloat(Double(cat.food)/10.0))
                foodText.text = String(cat.f)
                happyBar.animateValue(to:CGFloat(Double(cat.happy)/10.0))
                happyText.text = String(cat.happy)
            }
            else{
                Happy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Yummy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Hungry.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:1.0)
            }
        }
        else if flag==2 {
            if bird.food>0 {
                Happy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:1.0)
                Yummy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Hungry.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                bird.food=bird.food-1
                bird.happy=bird.happy+1
                foodBar.animateValue(to:CGFloat(Double(bird.food)/10.0))
                foodText.text = String(bird.f)
                happyBar.animateValue(to:CGFloat(Double(bird.happy)/10.0))
                happyText.text = String(bird.happy)
            }
            else{
                Happy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Yummy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Hungry.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:1.0)
            }
        }
        else if flag==3 {
            if bunny.food>0 {
                Happy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:1.0)
                Yummy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Hungry.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                bunny.food=bunny.food-1
                bunny.happy=bunny.happy+1
                foodBar.animateValue(to:CGFloat(Double(bunny.food)/10.0))
                foodText.text = String(bunny.f)
                happyBar.animateValue(to:CGFloat(Double(bunny.happy)/10.0))
                happyText.text = String(bunny.happy)
            }
            else{
                Happy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Yummy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Hungry.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:1.0)
            }
        }
        else if flag==4 {
            if fish.food>0 {
                Happy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:1.0)
                Yummy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Hungry.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                fish.food=fish.food-1
                fish.happy=fish.happy+1
                foodBar.animateValue(to:CGFloat(Double(fish.food)/10.0))
                foodText.text = String(fish.f)
                happyBar.animateValue(to:CGFloat(Double(fish.happy)/10.0))
                happyText.text = String(fish.happy)
            }
            else{
                Happy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Yummy.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:0.0)
                Hungry.textColor = UIColor(red:0/255.0,green:0/255.0,blue:0/255.0,alpha:1.0)
            }
        }
    }
}

