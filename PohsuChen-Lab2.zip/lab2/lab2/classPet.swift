import Foundation
import UIKit
class Pet {
    var happy:Int
    var food:Int
    var f:Int
    var color:UIColor
    init(color:UIColor) {
        self.happy=0
        self.food=0
        self.f=0
        self.color=color
    }
}
